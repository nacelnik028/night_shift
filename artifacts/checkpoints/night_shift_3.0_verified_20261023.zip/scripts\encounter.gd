extends Node3D
## Camera-relative rig. Never writes player rotation or movement state.
const P = preload("res://scripts/palette.gd")
var kind := "red_eyes"
var skull: Node3D
var jaw: Node3D
var arms: Array[Node3D] = []
var eyes: Array[Node3D] = []
var key_light: OmniLight3D

func _ready() -> void:
	var pale := P.material(Color("b2baaa"), 0.8, 0.12)
	var black := P.material(Color("060b0e"))
	var eye := P.material(Color("ed231a"), 0.5, 0.7)
	eye.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if kind == "absent":
		pale.albedo_color = Color("18232d")
		eye.albedo_color = Color("c6e8df")
		eye.emission = eye.albedo_color
	elif kind == "mimic":
		eye.albedo_color = Color("cfca9d")
		eye.emission = eye.albedo_color
	skull = Node3D.new()
	add_child(skull)
	P.ellipsoid(skull, Vector3(0, 0.08, 0), Vector3(0.61, 0.73, 0.42), pale)
	P.ellipsoid(skull, Vector3(0, 0.03, 0.24), Vector3(0.1, 0.22, 0.13), pale)
	P.box(skull, Vector3(0, -0.2, 0.16), Vector3(0.34, 0.31, 0.12), black)
	jaw = Node3D.new()
	jaw.position = Vector3(0, -0.23, 0.01)
	skull.add_child(jaw)
	P.ellipsoid(jaw, Vector3.ZERO, Vector3(0.46, 0.17, 0.35), pale)
	for side in [-1, 1]:
		var eye_y: float = 0.16 + (0.05 if side == 1 and kind in ["mimic", "final"] else 0.0)
		P.ellipsoid(skull, Vector3(side * 0.16, eye_y, 0.16), Vector3(0.22, 0.19, 0.16), black)
		eyes.append(P.ellipsoid(skull, Vector3(side * 0.16, eye_y, 0.245), Vector3(0.06, 0.07, 0.025), eye))
		P.ellipsoid(skull, Vector3(side * 0.29, 0.02, 0), Vector3(0.09, 0.2, 0.13), pale)
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.48, -0.4, -0.1)
		add_child(arm)
		arms.append(arm)
		P.cylinder(arm, Vector3(0, 0.26, 0), 0.055, 0.55, pale)
		P.ellipsoid(arm, Vector3(0, 0.57, 0), Vector3(0.16, 0.24, 0.09), pale)
		for i in range(4):
			P.cylinder(arm, Vector3(-0.06 + i * 0.04, 0.77, 0), 0.014, 0.28 + i * 0.025, pale)
	for i in range(8):
		P.box(skull, Vector3(-0.14 + i * 0.04, -0.08, 0.24), Vector3(0.025, 0.08 + (i % 2) * 0.02, 0.025), pale)
		P.box(jaw, Vector3(-0.14 + i * 0.04, 0.08, 0.17), Vector3(0.025, 0.07, 0.025), pale)
	key_light = OmniLight3D.new()
	key_light.position = Vector3(0.7, 0.4, 0.8)
	key_light.omni_range = 3
	key_light.light_energy = 1.4
	key_light.light_color = Color("b5d0cf") if kind == "absent" else Color("dbb69a")
	add_child(key_light)
	position.z = -2.8
	animate(0, false)

func animate(elapsed: float, reduced: bool) -> void:
	var t := clampf(elapsed, 0, 2)
	var lunge := smoothstep(0.12, 0.55, t)
	position.z = lerpf(-2.8, -0.78, lunge)
	position.x = 0
	position.y = 0
	rotation = Vector3.ZERO
	skull.rotation = Vector3.ZERO
	match kind:
		"mimic":
			position.x = (1.0 - lunge) * 0.9
			skull.rotation.z = lerpf(0.5, -0.15, lunge)
			jaw.position.y = -0.23 - smoothstep(0.35, 0.85, t) * 0.24
		"absent":
			position.z = lerpf(-3.5, -0.85, smoothstep(0.3, 0.72, t))
			position.y = (1 - lunge) * -0.35
			skull.scale.y = 1.15
			jaw.position.y = -0.3
		"final":
			position.y = (1.0 - lunge) * 0.7
			skull.rotation.z = lerpf(-0.9, 0.3, lunge)
			skull.scale.y = 1.25
			jaw.position.y = -0.23 - smoothstep(0.1, 0.5, t) * 0.28
		_:
			jaw.position.y = -0.23 - smoothstep(0.4, 0.65, t) * 0.16
	for i in range(arms.size()):
		arms[i].rotation.z = (1 if i == 0 else -1) * lerpf(0.75, -0.22, lunge)
		arms[i].position.z = lunge * 0.2
	var shake := sin(t * 41) * (0.003 if reduced else 0.018) * (1.0 - smoothstep(1.1, 1.6, t))
	position.x += shake
	rotation.z = shake * 0.5
	key_light.light_energy = 1.4 * (1.0 - smoothstep(1.35, 1.9, t))
