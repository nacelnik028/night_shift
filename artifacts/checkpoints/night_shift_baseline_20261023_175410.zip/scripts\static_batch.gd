extends RefCounted
## Group repeated static primitives without changing their physical/interaction bodies.
## Dynamic doors, clues, power fixtures and job targets are deliberately excluded.
static func build(world: Node3D) -> void:
	var excluded: Array[Node] = [world.apparition, world.detail.mirror_figure]
	excluded.append_array(world.stains)
	excluded.append_array(world.tubes)
	for door in world.doors.values():
		excluded.append(door.pivot)
	var groups: Dictionary = {}
	for node in world.find_children("*", "MeshInstance3D", true, false):
		if not node.is_visible_in_tree():
			continue
		var skip := false
		for branch in excluded:
			if branch == node or branch.is_ancestor_of(node):
				skip = true
				break
		if skip:
			continue
		var primitive := ""
		if node.mesh is BoxMesh:
			primitive = "box:" + str(node.mesh.size)
		elif node.mesh is CylinderMesh:
			primitive = "cylinder:%s:%s:%s:%s" % [node.mesh.height, node.mesh.top_radius, node.mesh.bottom_radius, node.mesh.radial_segments]
		else:
			continue
		if not node.material_override:
			continue
		var key := primitive + ":" + str(node.material_override.get_rid()) + ":" + str(node.layers) + ":" + str(node.cast_shadow)
		if not groups.has(key):
			groups[key] = []
		groups[key].append(node)
	var batched := 0
	for members in groups.values():
		if members.size() < 4:
			continue
		var first: MeshInstance3D = members[0]
		var instances := MultiMesh.new()
		instances.transform_format = MultiMesh.TRANSFORM_3D
		instances.mesh = first.mesh
		instances.instance_count = members.size()
		var batch := MultiMeshInstance3D.new()
		batch.name = "StaticBatch"
		batch.multimesh = instances
		batch.material_override = first.material_override
		batch.cast_shadow = first.cast_shadow
		batch.layers = first.layers
		world.add_child(batch)
		for i in range(members.size()):
			var source: MeshInstance3D = members[i]
			instances.set_instance_transform(i, world.global_transform.affine_inverse() * source.global_transform)
			source.set_meta("collision_proxy", true)
			source.visible = false
			batched += 1
	world.set_meta("batched_meshes", batched)
